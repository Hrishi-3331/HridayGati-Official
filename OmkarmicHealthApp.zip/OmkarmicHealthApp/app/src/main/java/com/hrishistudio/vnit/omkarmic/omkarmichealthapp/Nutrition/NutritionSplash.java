package com.hrishistudio.vnit.omkarmic.omkarmichealthapp.Nutrition;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.hrishistudio.vnit.omkarmic.omkarmichealthapp.R;

public class NutritionSplash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrition_splash);
    }
}
