package com.hrishistudio.vnit.omkarmic.omkarmichealthapp.Yoga;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.hrishistudio.vnit.omkarmic.omkarmichealthapp.R;

public class YogaPlanDescription extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yoga_plan_description);
    }
}
