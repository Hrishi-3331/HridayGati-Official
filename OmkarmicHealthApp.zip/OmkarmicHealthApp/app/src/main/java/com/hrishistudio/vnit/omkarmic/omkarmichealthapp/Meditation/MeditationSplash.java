package com.hrishistudio.vnit.omkarmic.omkarmichealthapp.Meditation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.hrishistudio.vnit.omkarmic.omkarmichealthapp.R;

public class MeditationSplash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meditation_splash);
    }
}
