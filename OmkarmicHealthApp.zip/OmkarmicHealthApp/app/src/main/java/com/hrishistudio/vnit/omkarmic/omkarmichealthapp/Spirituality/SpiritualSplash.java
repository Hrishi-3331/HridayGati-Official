package com.hrishistudio.vnit.omkarmic.omkarmichealthapp.Spirituality;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.hrishistudio.vnit.omkarmic.omkarmichealthapp.R;

public class SpiritualSplash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spiritual_splash);
    }
}
